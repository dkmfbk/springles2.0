/**
 * Base implementation.
 * 
 * @apiviz.exclude java\..*
 * @apiviz.exclude com\.google\.common\..*
 * @apiviz.exclude eu\.fbk\.dkm\.springles\.backend\..*
 * @apiviz.exclude eu\.fbk\.dkm\.springles\.inferencer\..*
 * @apiviz.exclude eu\.fbk\.dkm\.springles\.store\..*
 * @apiviz.exclude eu\.fbk\.dkm\.springles\.client\..*
 * @apiviz.exclude org\.openrdf\.repository\.base\..*
 */
package eu.fbk.dkm.springles.base;

