/**
 * API.
 * 
 * @apiviz.exclude java\..*
 * @apiviz.exclude eu\.fbk\.dkm\.springles\.base\..*
 * @apiviz.exclude eu\.fbk\.dkm\.springles\.client\..*
 * @apiviz.exclude eu\.fbk\.dkm\.springles\.store\..*
 */
package eu.fbk.dkm.springles;

