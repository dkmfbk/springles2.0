/**
 * Inference API and implementations.
 */
package eu.fbk.dkm.springles.inferencer;

