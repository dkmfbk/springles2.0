/**
 * Store implementation.
 * 
 * @apiviz.exclude com\.google\.common\..*
 * @apiviz.exclude eu\.fbk\.dkm\.springles\.store\..*
 */
package eu.fbk.dkm.springles.store;

