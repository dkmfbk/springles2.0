/**
 * Implementation package providing integration with the Sesame repository creation mechanism.
 */
package eu.fbk.dkm.internal.springles.config;

