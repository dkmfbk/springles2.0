/**
 * Implementation package providing general-purpose utility functions.
 */
package eu.fbk.dkm.internal.util;

