package eu.fbk.rdfpro;

import org.eclipse.rdf4j.rio.RDFHandler;

final class ProcessorKVWrite implements RDFProcessor {

    ProcessorKVWrite() {

    }

    @Override
    public RDFHandler wrap(RDFHandler handler) {
        // TODO Auto-generated method stub
        return null;
    }

}
