### List of third-party dependencies grouped by their license type.

#### BSD License:

  * Hamcrest Core (org.hamcrest:hamcrest-core:1.3)
  * OpenRDF Sesame: Model (org.openrdf.sesame:sesame-model:2.7.14)
  * OpenRDF Sesame: Rio - API (org.openrdf.sesame:sesame-rio-api:2.7.14)
  * OpenRDF Sesame: util (org.openrdf.sesame:sesame-util:2.7.14)

#### Eclipse Public License - Version 1.0:

  * JUnit (junit:junit:4.12-beta-2)

#### MIT License:

  * SLF4J API Module (org.slf4j:slf4j-api:1.7.10)
